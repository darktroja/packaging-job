<?php

$Token = '6332838966:AAEqWUi0AcLwNynZ7RpDmeROrg25bfZu2Bk';

$Id = '-1002135250938';